#!/usr/bin/env bash
set -euo pipefail
url="https://github.com/reallaksh19/3D_Converters/archive/e93cf16b9670a9876135a659b4f26506857b2c36.zip"
out="3D_Converters_pre_PR612_main_e93cf16b.zip"
curl -L "$url" -o "$out"
echo "Downloaded: $out"
